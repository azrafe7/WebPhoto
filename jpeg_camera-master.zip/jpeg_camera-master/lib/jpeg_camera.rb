module JpegCamera
  class Engine < ::Rails::Engine
  end
end
